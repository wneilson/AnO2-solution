UC Irvine Nuclear Science Workshop - Hands on activity

# Introduction
In these simulations, we simulate atoms in actinide oxides using a many-body potential, quantitatively predicting their thermomechanical properties.
